package oglib;
import java.io.IOException;

import oglib.components.CompileException;
import oglib.components.CreateException;
import oglib.components.Program;
import oglib.game.GameState;
import oglib.gui.Simple2DBuffer;
import oglib.gui.WindowGL;

import org.lwjgl.*;
import org.lwjgl.glfw.*;
import org.lwjgl.opengl.*;
import org.lwjgl.system.*;

import java.io.IOException;
import java.nio.*;

import com.google.common.base.Charsets;
import com.google.common.io.Resources;

import static org.lwjgl.glfw.Callbacks.*;
import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL30.*;
import static org.lwjgl.system.MemoryStack.*;
import static org.lwjgl.system.MemoryUtil.*;

public class Circulo {

    public static void main(String[] args) {
        var gameState = GameState.getGameState();
        var width = 300;
        var height = 300;
        var w = new WindowGL(width, height, "Ecuacion de la circunferencia", gameState);

        try {
            var program = new Program("screen.vert", "screen.frag");
            var screen = new Simple2DBuffer(width, height);
            var xT = 255;
//----------------------------------------------------------------------------------------------------
            /**
             * Para correrlo en la terminal se utiliza gradle runCircle, en esta parte podemos 
             * observar como es que se va a generar un circulo mediante la ecuacion de la 
             * circunferencia por algoritmo de punto medio, lo primero que se hace es graficar 
             * el punto central de la circunferencia para despues declarar las coordenadas xc, yc 
             * del punto central(origen), para despues definir el radio r, una vez que lo tenemos 
             * con nuestra p vamos a calcular el punto medio. Al tener estos datos se inicia el ciclo
             * de graficación el cual termina cuando x es igual o mayor que y, verificamos que el 
             * punto medio esta dentro de la circunferencia o de su perimetro o se ve que este fuera 
             * del perimetro de la circunferencia entonces si x esta fuera del rango de la 
             * circunferencia ese ciclo se termina. Una vez que acaba este proceso se grafica el punto
             * generado y dado que el circulo es simetrico en los cuatro cuadrantes del plano
             * se grafican las coordenadas con sus respectivos negativos o "espejos" simetricos 
             * obteniendo nuestro circulo completo. Par comprobarlo sabemos que si x=y significa que 
             * los pixeles ya fueron pintados y se verifica los puntos en los que x sea diferente 
             * de y.
             */
    
            screen.set(150,170,xT,xT,xT);
            int xc=150,yc=170;
            int r = 100;
            int x = r, y = 0;
            int p = 1-r;
            
            screen.set(xc,yc+r,xT,xT,xT);
            screen.set(xc,yc-r,xT,xT,xT);
            screen.set(xc+r,yc,xT,xT,xT);
        	screen.set(xc-r,yc,xT,xT,xT);
            
            while(x>=y) {
            	y++;
            	
            	if(p<=0) {
            		p = p+2*y+1;
            	}
            	
            	else {
            		x--;
            		p = p+2*y - 2*x+1;
            	}
            	
            	if(x<=y)
            		break;
            
            	screen.set(x+xc,y+yc,xT,xT,xT);
            	screen.set(-x+xc,y+yc,xT,xT,xT);
            	screen.set(x+xc,-y+yc,xT,xT,xT);
                screen.set(-x+xc,-y+yc,xT,xT,xT);
                
            	if(x!=y) {

            		screen.set(y+xc,x+yc,xT,xT,xT);
            		screen.set(-y+xc,x+yc,xT,xT,xT);
            		screen.set(y+xc,-x+yc,xT,xT,xT);
            		screen.set(-y+xc,-x+yc,xT,xT,xT);
            	}
            }
//-------------------------------------------------------------------------------------------------
            
            while (!w.windowShouldClose()) {
                glClearColor(0f, 0f, 0f, 1.0f);
                glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
                program.use();
                screen.draw();
                w.swapBuffers();
                w.pollEvents();
            }
            w.destroy();
        } catch (IOException | CreateException | CompileException e) {
            e.printStackTrace();
        }

    }

}