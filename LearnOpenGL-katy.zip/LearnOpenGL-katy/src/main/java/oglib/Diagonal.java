package oglib;

import java.io.IOException;

import oglib.components.CompileException;
import oglib.components.CreateException;
import oglib.components.Program;
import oglib.game.GameState;
import oglib.gui.Simple2DBuffer;
import oglib.gui.WindowGL;

import org.lwjgl.*;
import org.lwjgl.glfw.*;
import org.lwjgl.opengl.*;
import org.lwjgl.system.*;

import java.io.IOException;
import java.nio.*;

import com.google.common.base.Charsets;
import com.google.common.io.Resources;

import static org.lwjgl.glfw.Callbacks.*;
import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL30.*;
import static org.lwjgl.system.MemoryStack.*;
import static org.lwjgl.system.MemoryUtil.*;

public class Diagonal {

    public static void main(String[] args) {
        var gameState = GameState.getGameState();
        var width = 300;
        var height = 300;
        var w = new WindowGL(width, height, "Ecuacion de la recta", gameState);

        try {
            var program = new Program("screen.vert", "screen.frag");
            var screen = new Simple2DBuffer(width, height);
            var xT = 255;
//----------------------------------------------------------------------------------------------------           
            /**
             * Para correrlo en la terminal se utiliza gradle runWindowGL, en esta parte podemos
             * observar como se va a hace una linea la cual se genera mediante la ecuacion de 
             * la linea punto pendiente y = mx+b || x = my+b, para comenzar definimos las 
             * coordenadas y calculamos la diferencia en x e y, asi mismo se grafica el punto inicial
             * despues comparamos los valores absolutos de las diferencias en x e y para encontrar
             * la mayor, calculamos la pendiente, en este caso <1, se grafica respecto del eje x
             * se incrementa en x y redondeamos y = mx+b, este mismo proceso se repite para la 
             * pendiente mayor a 1 y graficamos respecto a y para al final redondearlo dependiendo de las
             * coordenadas dadas 
             * 
             */
            
            int x1=20,y1=20,x2=280,y2=280;
            //prueba
           // int x1=10,y1=10,x2=11,y2=50;
            int dx = x2 - x1;
            int dy = y2 - y1;

            
            screen.set(x1, y1, xT, xT, xT);
            if (Math.abs(dx) > Math.abs(dy)) {          
            	
                float m = (float) dy / (float) dx;
                float b = y1 - m*x1;
                if(dx<0)
                    dx =  -1;
                else
                    dx =  1;
                while (x1 != x2) {
                	
                    x1 += dx;
                    y1 = Math.round(m*x1 + b);
                    
                    screen.set(x1, y1, xT, xT, xT);
                }
            }

            else           
            if (dy != 0) {                            
                float m = (float) dx / (float) dy;      
                float b = x1 - m*y1;
                if(dy<0)
                    dy =  -1;
                else
                    dy =  1;
               
                while (y1 != y2) {
                    y1 += dy;
                    x1 = Math.round(m*y1 + b);
                    screen.set(x1, y1, xT, xT, xT);
                }
            }            
//--------------------------------------------------------------------------------------------------

            while (!w.windowShouldClose()) {
                glClearColor(0f, 0f, 0f, 1.0f);
                glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
                program.use();
                screen.draw();
                w.swapBuffers();
                w.pollEvents();
            }
            w.destroy();
        } catch (IOException | CreateException | CompileException e) {
            e.printStackTrace();
        }

    }

}
