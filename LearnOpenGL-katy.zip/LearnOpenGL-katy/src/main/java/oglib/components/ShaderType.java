package oglib.components;

public enum ShaderType {
    VERTEX, FRAGMENT
}
